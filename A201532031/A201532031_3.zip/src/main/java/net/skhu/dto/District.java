package net.skhu.dto;

import java.io.Serializable;

public class District implements Serializable{
	
	int id;
	String districtName;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getDistrictName() {
		return districtName;
	}
	public void setDistrictName(String districtName) {
		this.districtName = districtName;
	}
	
}
