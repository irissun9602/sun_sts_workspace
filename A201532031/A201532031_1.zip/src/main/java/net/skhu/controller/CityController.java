package net.skhu.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import net.skhu.dto.City;
import net.skhu.dto.District;

import net.skhu.mapper.CityMapper;
import net.skhu.mapper.DistrictMapper;

@Controller
@RequestMapping("/city")
public class CityController {

    @Autowired CityMapper cityMapper;
    @Autowired DistrictMapper districtMapper;
    

    @RequestMapping("list")
    public String list(Model model) {
        List<City>cities = cityMapper.findAll();
        model.addAttribute("cities", cities);
        return "city/list";
    }

}