package net.skhu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Mybatis1Employee1Application {

	public static void main(String[] args) {
		SpringApplication.run(Mybatis1Employee1Application.class, args);
	}
}
