package net.skhu.domain;

public class City {

}
